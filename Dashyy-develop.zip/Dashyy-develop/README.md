# Dashyy
CS7455 
Summer 2020   
Term Project    
Team 5  
  Version: v0.0.1

## License
ANY USE OF THIS PROJECTS CODE, IDEA, OR ASSETS IS STRICTLY FORBIDDEN WITHOUT WRITTEN CONSENT

## Code Agreement
  By downloading any version of this project you agree that another individuals source cannot be pulled from this project, for use in another project without his/her and the teams' permission.
  
  All source added to the project become apart of the project, and therefore have to abide by our agreement above.

  If a team member leaves the project, their source remains within the project at the discretion of the project owner. The team member leaving cannot remove their code, but reserve the right to use THEIR code in any future projects as they wish, but not at any point will they have the right to use anything they did not create.

  Any script or item one makes should have ones personal signature on any portion of the project they made. They will forever have the right to use that creation. 

### Who To Talk To:
 John M - john.murwin [@] gmail.com   
 Mike A - maufiero [@] gmail.com
 Scott R -  scottrobinson4591@gmail.com



This project is still in development, as such Readme, code, and other assets are subject to change. 
This is a test.

