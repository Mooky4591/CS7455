package com.example.lab5;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import androidx.annotation.Nullable;
import java.util.Random;

public class MyService extends Service {
    public char randomLetter;
    private boolean isRandomLetterGeneratorOn;
    private final String TAG = "MyActivity";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "In onStartCommand, thread id: " +Thread.currentThread().getId());
        isRandomLetterGeneratorOn = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                startRandomNumberGenerator();
            }
        }).start();
        return START_STICKY;
    }

    private void startRandomNumberGenerator() {
        while (isRandomLetterGeneratorOn) {
            try {
                Thread.sleep(1000);
                if (isRandomLetterGeneratorOn) {
                    Random rnd = new Random();
                    randomLetter = (char) (rnd.nextInt(26) + 'a');

                    Intent intent = new Intent();
                    intent.setAction("com.example.lab5.myreceiver");
                    intent.putExtra("char", randomLetter);
                    sendBroadcast(intent);
                    Log.i(TAG, "Random letter: " + randomLetter);
                }
            } catch (InterruptedException e) {
                Log.i(TAG, "Thread Interrupted");
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopRandomNumberGenerator();
        Log.i(TAG, "Service Destroyed.");
    }

    private void stopRandomNumberGenerator() {
        isRandomLetterGeneratorOn = false;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent){
        return null ;
    }
}
