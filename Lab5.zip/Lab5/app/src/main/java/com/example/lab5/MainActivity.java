//Scott Robinson
//Lab 6
//CS7455

package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MyActivity";
    Button start;
    Button stop;
    TextView text;
    Intent serviceIntent;
    MyService myService;
    Boolean isServiceBound;
    ServiceConnection serviceConnection;
    MyReceiver broadcastReceiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        start = (Button) findViewById(R.id.startServiceButton);
        stop = (Button) findViewById(R.id.stopServiceButton);
        text = (TextView) findViewById(R.id.letterTextView);
        broadcastReceiver = new MyReceiver(this);

        IntentFilter IF = new IntentFilter("com.example.lab5.myreceiver");
        registerReceiver(broadcastReceiver, IF);


        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.addCategory(Intent.CATEGORY_DEFAULT);
                intent.setAction("com.example.lab5.myreceiver");
                sendBroadcast(intent);
                startService(serviceIntent);
            }
        });
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(serviceIntent);
            }
        });

        serviceIntent = new Intent(getApplicationContext(), MyService.class);
    }

    public void setRandomLetter(final char letterReceived) {

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                text.setText("Random Character: " + Character.toString(letterReceived));
                //Log.i(TAG, "Random Letter: ");
            }
        });
    }
}

