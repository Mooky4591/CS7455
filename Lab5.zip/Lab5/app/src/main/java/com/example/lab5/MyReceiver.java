package com.example.lab5;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class MyReceiver extends BroadcastReceiver {
    String tag = "Broadcast Tag";

    char letterReceived;
    private MainActivity mainActivity;

    public MyReceiver (MainActivity mainActivity){
        this.mainActivity = mainActivity;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context, "Broadcast Received", Toast.LENGTH_LONG).show();
        letterReceived = intent.getCharExtra("char", ' ');
        mainActivity.setRandomLetter(letterReceived);
        Log.i(tag, "Broadcast Received");
    }
}
